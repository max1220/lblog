-- Generate the password values like this: echo -n "Your password here".
-- You might want to consider using cat instead of echo on a multiuser system.

return {
	["max"] = { password = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3" }
}
